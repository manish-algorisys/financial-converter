# Visual Guide: Review & Edit Feature

## 📺 Streamlit UI Walkthrough

### Tab 1: Upload & Parse

```
┌─────────────────────────────────────────────────────────────────┐
│  📊 Financial Document Parser                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Tab: [📤 Upload & Parse] [✏️ Review & Edit] [📊 View Results] │
│                                                                  │
│  Upload Financial Document                                       │
│  ─────────────────────────────                                  │
│                                                                  │
│  ┌──────────────────────────┐  ┌──────────────┐               │
│  │ Choose a PDF file        │  │  Company:    │               │
│  │ [Browse files...]        │  │  BRITANNIA ▼ │               │
│  │                          │  └──────────────┘               │
│  │  📄 Britannia Q2.pdf     │                                  │
│  │  (1.2 MB)                │                                  │
│  └──────────────────────────┘                                  │
│                                                                  │
│  [🚀 Parse Document]  [🗑️ Clear]                               │
│                                                                  │
│  ✅ Document parsed successfully!                               │
│  ⏱️ Processing time: 45.23 seconds                             │
│                                                                  │
│  Extracted Financial Data (Preview)                             │
│  ────────────────────────────────────────                       │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Particular              │ 30.06.2025 │ 31.03.2025 │ ...  │  │
│  ├─────────────────────────┼────────────┼────────────┼──────┤  │
│  │ Sale of goods           │  4,588.04  │  4,244.77  │ ...  │  │
│  │ Other operating revenue │     91.18  │     75.64  │ ...  │  │
│  │ Total revenue           │  4,679.22  │  4,320.41  │ ...  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  💡 Switch to '✏️ Review & Edit' tab to modify the data.       │
│                                                                  │
│  📥 Download Results                                            │
│  ────────────────────                                           │
│  [📄 Download JSON] [📊 Download CSV] [📝 Download Markdown]   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Tab 2: Review & Edit ⭐ NEW

```
┌─────────────────────────────────────────────────────────────────┐
│  📊 Financial Document Parser                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Tab: [📤 Upload & Parse] [✏️ Review & Edit] [📊 View Results] │
│                                                                  │
│  Review & Edit Financial Data                                   │
│  ─────────────────────────────                                  │
│                                                                  │
│  Company: BRITANNIA                                             │
│  Document: Britannia Unaudited Q2 June 2026                     │
│  ─────────────────────────────────────────────────────────────  │
│                                                                  │
│  💡 Review and edit the extracted data below.                   │
│      Click 'Save Changes' when done.                            │
│                                                                  │
│  ╔═══════════════════════════════════════════════════════════╗ │
│  ║ EDITABLE TABLE                                            ║ │
│  ╠═══════════════╤═══════════════════════╤════════╤═════════╣ │
│  ║ Key           │ Particular            │ 30.06. │ 31.03.  ║ │
│  ║               │                       │  2025  │  2025   ║ │
│  ╠═══════════════╪═══════════════════════╪════════╪═════════╣ │
│  ║ sale_of_goods │ Sale of goods        │ 4588.04│ 4244.77 ║ │
│  ║               │ [Click to edit]       │  [✏️]  │  [✏️]   ║ │
│  ╠───────────────┼───────────────────────┼────────┼─────────╣ │
│  ║ other_op_rev  │ Other operating      │  91.18 │  75.64  ║ │
│  ║               │ revenues [Click edit] │  [✏️]  │  [✏️]   ║ │
│  ╠───────────────┼───────────────────────┼────────┼─────────╣ │
│  ║ total_revenue │ Total revenue        │ 4679.22│ 4320.41 ║ │
│  ║               │ [Click to edit]       │  [✏️]  │  [✏️]   ║ │
│  ╠───────────────┴───────────────────────┴────────┴─────────╣ │
│  ║  [+] Add Row                                             ║ │
│  ╚═══════════════════════════════════════════════════════════╝ │
│                                                                  │
│  [💾 Save Changes]  [📄 Save as New]                           │
│                                                                  │
│  🔍 View Changes ▼                                              │
│  ─────────────────                                              │
│  │ Modified cells highlighted                                  │
│  │ Original: 4588.04 → New: 4600.00                           │
│  └─────────────────────────────────────────────────────────    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

### Tab 3: View Results

```
┌─────────────────────────────────────────────────────────────────┐
│  📊 Financial Document Parser                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Tab: [📤 Upload & Parse] [✏️ Review & Edit] [📊 View Results] │
│                                                                  │
│  View Parsing Results                                           │
│  ─────────────────────────                                      │
│                                                                  │
│  Company: BRITANNIA                                             │
│  ─────────────────────────                                      │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ Particular              │ 30.06.2025 │ 31.03.2025 │ ...  │  │
│  ├─────────────────────────┼────────────┼────────────┼──────┤  │
│  │ Sale of goods           │  4,588.04  │  4,244.77  │ ...  │  │
│  │ Other operating revenue │     91.18  │     75.64  │ ...  │  │
│  │ Total revenue           │  4,679.22  │  4,320.41  │ ...  │  │
│  │ Other income            │    157.22  │    142.89  │ ...  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  🔍 View Raw JSON ▼                                             │
│  ───────────────────                                            │
│  {                                                              │
│    "company_name": "BRITANNIA",                                │
│    "financial_data": [...]                                     │
│  }                                                              │
│                                                                  │
│  📁 Generated Files ▼                                           │
│  ────────────────────                                           │
│  json: Britannia-financial-data.json                           │
│  csv_1: Britannia-table-1.csv                                  │
│  html_1: Britannia-table-1.html                                │
│  md_1: Britannia-table-1.md                                    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 🎬 User Flow

### Scenario 1: Quick Review and Save

```
1. User uploads PDF
   ↓
2. System parses and extracts data
   ↓
3. User clicks "Review & Edit" tab
   ↓
4. User reviews data in editable table
   ↓
5. User clicks a cell to edit (e.g., fixes "4,58" → "4,588")
   ↓
6. User clicks "💾 Save Changes"
   ↓
7. System saves to original file
   ↓
8. Success message: "✅ Changes saved successfully!"
```

### Scenario 2: Create Edited Version

```
1. User uploads PDF
   ↓
2. System parses and extracts data
   ↓
3. User clicks "Review & Edit" tab
   ↓
4. User makes multiple edits:
   - Corrects OCR errors
   - Adds missing row
   - Updates values
   ↓
5. User clicks "📄 Save as New"
   ↓
6. System creates new file: *-financial-data-edited.json
   ↓
7. Success: "✅ New version saved!"
   ↓
8. Both files preserved:
   - Original: *-financial-data.json
   - Edited: *-financial-data-edited.json
```

## 🎨 UI Elements

### Buttons

| Button            | Icon | Action          | Location           |
| ----------------- | ---- | --------------- | ------------------ |
| Parse Document    | 🚀   | Start parsing   | Upload tab         |
| Clear             | 🗑️   | Reset session   | Upload tab         |
| Save Changes      | 💾   | Overwrite file  | Edit tab           |
| Save as New       | 📄   | Create new file | Edit tab           |
| Download JSON     | 📄   | Export JSON     | Upload/Results tab |
| Download CSV      | 📊   | Export CSV      | Upload tab         |
| Download Markdown | 📝   | Export MD       | Upload tab         |

### Data Editor Features

```
Features available in the editable table:

✏️  Click any cell to edit
➕  Add new rows with [+ Add Row] button
❌  Delete rows with [×] button in row
🔢  Auto-formatting for numbers
📋  Copy/paste support
↕️  Sortable columns (click header)
🔍  Search within table (Ctrl+F)
📊  Column resizing (drag borders)
```

## 💡 Tips for Users

### Editing Tips

1. **Click to Edit**: Simply click any cell to start editing
2. **Tab Navigation**: Use Tab key to move between cells
3. **Enter to Confirm**: Press Enter to confirm changes
4. **Esc to Cancel**: Press Esc to cancel editing

### Data Entry

- Numbers can include commas: `4,588.04`
- Text can include special characters
- Empty cells are allowed
- Keys should be unique identifiers

### Comparison View

The "View Changes" expander shows:

- Original values (before editing)
- Modified values (after editing)
- Side-by-side comparison
- Highlighting of changed cells

## 🔄 State Management

```
Session State Variables:
├── parsed_data          # Parsed financial data
├── output_files         # Paths to generated files
├── document_name        # Name of uploaded document
└── processing_time      # Time taken to parse
```

## 📝 Notes

- **Auto-save**: Changes are NOT automatically saved
- **Persistence**: Edits remain until you click Save
- **Validation**: Basic validation on save
- **Undo**: Use browser refresh to discard unsaved changes
- **Multiple tabs**: Keep only one editing session active at a time

---

This visual guide helps users understand the new editing interface and workflow!
