# Quick Reference: PDF Optimization Features

## What's New in v2.0?

### 1. No More Hardcoded Dates! 🎉

**Before:** Only worked for June 2025 statements  
**Now:** Automatically detects any date format (Q1, Q2, Q3, Q4, any year)

### 2. Smarter Page Finding 🔍

**Before:** Simple regex, often failed  
**Now:** Multi-priority detection with 3 fallback levels

### 3. Works with Different PDF Layouts 📄

**Before:** Strict row numbers only  
**Now:** Fuzzy matching automatically finds rows by label

### 4. Auto-Selects Best Table 🎯

**Before:** Always used first table  
**Now:** Scores all tables, picks the best financial statement

### 5. Better Error Recovery 🛡️

**Before:** Failed completely on errors  
**Now:** Retry logic, fallback strategies, graceful degradation

## Quick Start

### API Usage (Default - Recommended)

```bash
curl -X POST http://localhost:5000/api/parse \
  -F "file=@statement.pdf" \
  -F "company_name=HUL"
```

### API Usage (Custom Options)

```bash
curl -X POST http://localhost:5000/api/parse \
  -F "file=@statement.pdf" \
  -F "company_name=BRITANNIA" \
  -F "prefer_standalone=true" \
  -F "use_fuzzy_matching=true"
```

### Python Usage

```python
from pathlib import Path
from parser_core import process_pdf_document, load_config

config = load_config()
result = process_pdf_document(
    pdf_path=Path("statement.pdf"),
    company_name="HUL",
    output_dir=Path("output"),
    config=config,
    prefer_standalone=True,    # NEW
    use_fuzzy_matching=True    # NEW
)

# Check results
if result["success"]:
    print(f"Extracted {len(result['json_result']['financial_data'])} items")
    print(f"Used table {result['table_info']['selected_table']} of {result['table_info']['total_tables']}")
    print(f"Method: {result['json_result']['metadata']['extraction_method']}")
```

## Parameters Explained

### `prefer_standalone` (default: true)

- **true**: Prioritize standalone over consolidated statements
- **false**: Accept consolidated if standalone not found

**When to use false:**

- PDF only has consolidated statements
- Testing with different statement types

### `use_fuzzy_matching` (default: true)

- **true**: Enable fallback label matching when row numbers fail
- **false**: Strict row-number matching only

**When to use false:**

- You have exact row numbers and want strict validation
- Debugging to see which fields are failing

## Understanding the Response

### Table Info

```json
{
  "table_info": {
    "total_tables": 3, // How many tables found in PDF
    "selected_table": 1, // Which table was used for extraction
    "selection_method": "heuristic" // How it was selected
  }
}
```

**Selection Methods:**

- `single_table`: Only one table found
- `heuristic`: Multiple tables, used scoring to select best
- `default`: Fallback to first table

### Metadata

```json
{
  "metadata": {
    "source_file": "statement.pdf",
    "table_number": 1,
    "total_tables": 3,
    "extraction_method": "mixed", // How data was extracted
    "processing_time_seconds": 45.2
  }
}
```

**Extraction Methods:**

- `tr_number`: All rows found using configured row numbers (best)
- `mixed`: Some rows by number, some by fuzzy matching
- `fuzzy`: Mostly fuzzy matching (PDF format differs from config)

## Common Scenarios

### Scenario 1: Different Quarter/Year

**Problem:** Need to parse Q3 2024 statement, config has Q2 2025  
**Solution:** Just run it! Date patterns are now flexible.

```bash
curl -X POST http://localhost:5000/api/parse \
  -F "file=@Q3_2024_statement.pdf" \
  -F "company_name=HUL"
# Works automatically!
```

### Scenario 2: PDF Format Changed

**Problem:** Company changed their PDF layout, row numbers wrong  
**Solution:** Fuzzy matching handles it automatically.

```python
# Fuzzy matching enabled by default
result = process_pdf_document(..., use_fuzzy_matching=True)

# Check if fuzzy matching was used
if result['json_result']['metadata']['extraction_method'] == 'mixed':
    print("Some rows found by label matching - PDF format may have changed")
```

### Scenario 3: Multiple Tables in PDF

**Problem:** PDF has 5 tables, which is the right one?  
**Solution:** Auto-selection picks the best one.

```python
result = process_pdf_document(...)

table_info = result['table_info']
print(f"Found {table_info['total_tables']} tables")
print(f"Selected table {table_info['selected_table']}")

# Verify by checking output files
print(result['output_files'])  # All tables exported
```

### Scenario 4: Only Consolidated Statement

**Problem:** PDF has consolidated, not standalone  
**Solution:** Set `prefer_standalone=false`

```bash
curl -X POST http://localhost:5000/api/parse \
  -F "file=@consolidated.pdf" \
  -F "company_name=ITC" \
  -F "prefer_standalone=false"
```

## Testing

### Test All Samples

```bash
python test_optimization.py
```

### Test Different Configurations

```bash
python test_optimization.py --config-test
```

### Test Single File

```python
python test_optimization.py
# Edit main() to specify your test file
```

## Debugging

### Enable Debug Logs

```python
import logging
logging.basicConfig(level=logging.DEBUG)

result = process_pdf_document(...)
# See detailed matching and selection logs
```

### Check Which Fields Failed

```python
result = process_pdf_document(...)

if result['success']:
    expected_count = 35  # Based on config
    actual_count = len(result['json_result']['financial_data'])

    if actual_count < expected_count:
        print(f"Missing {expected_count - actual_count} fields")
        print("Check logs for 'Could not find row for key' warnings")
```

### Manually Try Different Tables

```python
from parser_core import parse_html_table_to_json, load_config

config = load_config()

# Try each table manually
for table_num in [1, 2, 3]:
    html_path = Path(f"output/doc-name-table-{table_num}.html")
    if html_path.exists():
        result = parse_html_table_to_json(html_path, "HUL", config)
        print(f"Table {table_num}: {len(result['financial_data'])} items")
```

## Performance Tips

1. **Single Page Processing**: Fastest, enabled automatically when page detected
2. **Disable Fuzzy Matching**: If you have exact row numbers, disable for speed
   ```python
   result = process_pdf_document(..., use_fuzzy_matching=False)
   ```
3. **Reuse Exports**: All tables exported once, parse different tables without reprocessing

## Migration from v1.0

Your existing code works unchanged:

```python
# v1.0 code still works
result = process_pdf_document(pdf_path, company_name, output_dir, config)
```

To use new features, just add parameters:

```python
# v2.0 optimized
result = process_pdf_document(
    pdf_path, company_name, output_dir, config,
    prefer_standalone=True,
    use_fuzzy_matching=True
)
```

## Getting Help

1. **Check logs**: Enable DEBUG logging
2. **Review exports**: Check HTML files in output directory
3. **Test configurations**: Use `test_optimization.py --config-test`
4. **Read full docs**: See [PDF_OPTIMIZATION.md](PDF_OPTIMIZATION.md)

## Summary

✅ **Do's:**

- Use default settings (they're optimized)
- Check `table_info` and `metadata` in results
- Enable debug logs if something's wrong
- Test new PDF formats with `test_optimization.py`

❌ **Don'ts:**

- Don't disable fuzzy matching unless you have exact row numbers
- Don't assume first table is correct (check `table_info`)
- Don't hardcode for specific dates (it's flexible now)

## Support Checklist

When reporting issues, provide:

- [ ] PDF file (if possible)
- [ ] Company name used
- [ ] Complete error message
- [ ] Debug logs (`logging.basicConfig(level=logging.DEBUG)`)
- [ ] `table_info` from result
- [ ] `extraction_method` from metadata

---

**Version:** 2.0  
**Last Updated:** December 2025  
**Full Documentation:** [PDF_OPTIMIZATION.md](PDF_OPTIMIZATION.md)
